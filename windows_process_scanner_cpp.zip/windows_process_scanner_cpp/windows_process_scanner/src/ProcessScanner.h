#pragma once

#include <windows.h>
#include <string>
#include <vector>
#include <unordered_map>

enum class Severity {
    Low,
    Medium,
    High
};

struct Finding {
    int points{};
    std::wstring category;
    std::wstring message;
};

struct ProcessInfo {
    DWORD pid{};
    DWORD parentPid{};
    std::wstring name;
    std::wstring path;
    std::wstring commandLine;
    std::wstring signer;
    std::wstring sha256;

    bool pathResolved{};
    bool signatureValid{};
    bool isWindowsSystemProcess{};

    int score{};
    Severity severity{Severity::Low};
    std::vector<Finding> findings;
};

class ProcessScanner {
public:
    std::vector<ProcessInfo> Scan();

private:
    std::vector<ProcessInfo> EnumerateProcesses();
    void AnalyzeProcess(
        ProcessInfo& p,
        const std::unordered_map<DWORD, ProcessInfo*>& byPid);

    void ValidatePath(ProcessInfo& p);
    void ValidateParent(
        ProcessInfo& p,
        const std::unordered_map<DWORD, ProcessInfo*>& byPid);
    void ValidateSignature(ProcessInfo& p);
    void IdentifyHash(ProcessInfo& p);
    void ValidateKnownNamePath(ProcessInfo& p);
    void ValidateModules(ProcessInfo& p);
    void CheckMemoryModuleAnomalies(ProcessInfo& p);

    static void AddFinding(
        ProcessInfo& p,
        int points,
        const wchar_t* category,
        const wchar_t* message);

    static void FinalizeScore(ProcessInfo& p);

    static std::wstring ToLower(std::wstring value);
    static bool ContainsI(
        const std::wstring& text,
        const std::wstring& value);

    static std::wstring GetProcessPath(DWORD pid);
    static std::wstring GetProcessCommandLine(DWORD pid);
    static std::wstring Sha256File(const std::wstring& path);
    static bool VerifyAuthenticode(
        const std::wstring& path,
        std::wstring& signer);

    static bool IsSystemProcessName(const std::wstring& name);
    static bool IsExpectedSystemPath(const std::wstring& name,
                                     const std::wstring& path);
};

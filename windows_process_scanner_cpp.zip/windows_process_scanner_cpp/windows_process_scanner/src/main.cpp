#include "ProcessScanner.h"

#include <iostream>
#include <locale>
#include <algorithm>

static const wchar_t* SeverityName(Severity s)
{
    switch (s)
    {
        case Severity::High:
            return L"HIGH";

        case Severity::Medium:
            return L"MEDIUM";

        default:
            return L"LOW";
    }
}

int wmain()
{
    std::locale::global(std::locale(""));

    ProcessScanner scanner;

    auto processes = scanner.Scan();

    std::sort(
        processes.begin(),
        processes.end(),
        [](const ProcessInfo& a, const ProcessInfo& b)
        {
            return a.score > b.score;
        });

    std::wcout
        << L"Windows Process Scanner\n"
        << L"=======================\n"
        << L"Processes analyzed: "
        << processes.size()
        << L"\n\n";

    for (const auto& p : processes)
    {
        // LOW results are still available in the data model,
        // but only MEDIUM/HIGH are printed to keep output useful.
        if (p.severity == Severity::Low)
            continue;

        std::wcout
            << L"[" << SeverityName(p.severity) << L"] "
            << p.name
            << L"  PID=" << p.pid
            << L"  Score=" << p.score
            << L"\n";

        std::wcout
            << L"  Path: "
            << (p.path.empty() ? L"<unavailable>" : p.path)
            << L"\n";

        std::wcout
            << L"  Parent PID: "
            << p.parentPid
            << L"\n";

        std::wcout
            << L"  Signature: "
            << (p.signatureValid ? L"valid" : L"not validated")
            << L"\n";

        if (!p.sha256.empty())
        {
            std::wcout
                << L"  SHA-256: "
                << p.sha256
                << L"\n";
        }

        for (const auto& f : p.findings)
        {
            std::wcout
                << L"    +"
                << f.points
                << L" ["
                << f.category
                << L"] "
                << f.message
                << L"\n";
        }

        std::wcout << L"\n";
    }

    return 0;
}

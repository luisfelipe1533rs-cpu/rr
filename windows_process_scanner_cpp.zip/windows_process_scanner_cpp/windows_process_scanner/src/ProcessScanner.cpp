#include "ProcessScanner.h"

#include <tlhelp32.h>
#include <wincrypt.h>
#include <wintrust.h>
#include <softpub.h>

#include <algorithm>
#include <cwctype>
#include <sstream>
#include <iomanip>
#include <memory>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "wintrust.lib")

namespace {

std::wstring BaseName(const std::wstring& path)
{
    const auto pos = path.find_last_of(L"\\/");
    if (pos == std::wstring::npos)
        return path;

    return path.substr(pos + 1);
}

bool IsWindowsDirectory(const std::wstring& path)
{
    return ProcessScanner::ContainsI(path, L"\\windows\\");
}

}

std::wstring ProcessScanner::ToLower(std::wstring value)
{
    std::transform(
        value.begin(),
        value.end(),
        value.begin(),
        [](wchar_t c) {
            return static_cast<wchar_t>(std::towlower(c));
        });

    return value;
}

bool ProcessScanner::ContainsI(
    const std::wstring& text,
    const std::wstring& value)
{
    return ToLower(text).find(ToLower(value)) != std::wstring::npos;
}

void ProcessScanner::AddFinding(
    ProcessInfo& p,
    int points,
    const wchar_t* category,
    const wchar_t* message)
{
    p.score += points;

    p.findings.push_back({
        points,
        category,
        message
    });
}

void ProcessScanner::FinalizeScore(ProcessInfo& p)
{
    if (p.score >= 60)
        p.severity = Severity::High;
    else if (p.score >= 30)
        p.severity = Severity::Medium;
    else
        p.severity = Severity::Low;
}

std::wstring ProcessScanner::GetProcessPath(DWORD pid)
{
    HANDLE h = OpenProcess(
        PROCESS_QUERY_LIMITED_INFORMATION,
        FALSE,
        pid);

    if (!h)
        return L"";

    wchar_t buffer[32768]{};
    DWORD size = static_cast<DWORD>(std::size(buffer));

    std::wstring result;

    if (QueryFullProcessImageNameW(
            h,
            0,
            buffer,
            &size))
    {
        result.assign(buffer, size);
    }

    CloseHandle(h);
    return result;
}

std::wstring ProcessScanner::GetProcessCommandLine(DWORD pid)
{
    // Deliberately conservative:
    // command-line retrieval through undocumented PEB access is avoided.
    // The scanner can still operate without it.
    (void)pid;
    return L"";
}

std::vector<ProcessInfo> ProcessScanner::EnumerateProcesses()
{
    std::vector<ProcessInfo> result;

    HANDLE snapshot = CreateToolhelp32Snapshot(
        TH32CS_SNAPPROCESS,
        0);

    if (snapshot == INVALID_HANDLE_VALUE)
        return result;

    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);

    if (Process32FirstW(snapshot, &pe))
    {
        do
        {
            ProcessInfo p;
            p.pid = pe.th32ProcessID;
            p.parentPid = pe.th32ParentProcessID;
            p.name = pe.szExeFile;
            p.path = GetProcessPath(p.pid);
            p.commandLine = GetProcessCommandLine(p.pid);
            p.pathResolved = !p.path.empty();

            result.push_back(std::move(p));

        } while (Process32NextW(snapshot, &pe));
    }

    CloseHandle(snapshot);
    return result;
}

bool ProcessScanner::IsSystemProcessName(
    const std::wstring& name)
{
    const auto n = ToLower(BaseName(name));

    static const wchar_t* names[] = {
        L"lsass.exe",
        L"csrss.exe",
        L"smss.exe",
        L"winlogon.exe",
        L"wininit.exe",
        L"services.exe",
        L"svchost.exe",
        L"spoolsv.exe",
        L"dwm.exe",
        L"conhost.exe",
        L"taskhostw.exe",
        L"sihost.exe"
    };

    for (auto x : names)
        if (n == x)
            return true;

    return false;
}

bool ProcessScanner::IsExpectedSystemPath(
    const std::wstring& name,
    const std::wstring& path)
{
    const auto n = ToLower(BaseName(name));
    const auto p = ToLower(path);

    if (n == L"lsass.exe" ||
        n == L"csrss.exe" ||
        n == L"smss.exe" ||
        n == L"winlogon.exe" ||
        n == L"wininit.exe" ||
        n == L"services.exe" ||
        n == L"spoolsv.exe" ||
        n == L"dwm.exe")
    {
        return p.find(L"\\windows\\system32\\") != std::wstring::npos;
    }

    if (n == L"svchost.exe")
    {
        return p.find(L"\\windows\\system32\\svchost.exe") !=
               std::wstring::npos;
    }

    return true;
}

void ProcessScanner::ValidatePath(ProcessInfo& p)
{
    if (!p.pathResolved)
    {
        AddFinding(
            p,
            10,
            L"Path",
            L"Executable path could not be resolved");
        return;
    }

    const auto path = ToLower(p.path);

    if (ContainsI(path, L"\\appdata\\local\\temp\\") ||
        ContainsI(path, L"\\windows\\temp\\") ||
        ContainsI(path, L"\\temp\\"))
    {
        AddFinding(
            p,
            15,
            L"Path",
            L"Executable is located in a temporary directory");
    }

    if (ContainsI(path, L"\\downloads\\"))
    {
        AddFinding(
            p,
            8,
            L"Path",
            L"Executable is located in a Downloads directory");
    }
}

void ProcessScanner::ValidateParent(
    ProcessInfo& p,
    const std::unordered_map<DWORD, ProcessInfo*>& byPid)
{
    if (p.pid <= 4 || p.parentPid == 0)
        return;

    if (p.parentPid == p.pid)
    {
        AddFinding(
            p,
            30,
            L"Parent",
            L"Process reports itself as its parent");
        return;
    }

    if (!byPid.count(p.parentPid))
    {
        AddFinding(
            p,
            15,
            L"Parent",
            L"Parent PID is not currently present");
    }
}

bool ProcessScanner::VerifyAuthenticode(
    const std::wstring& path,
    std::wstring& signer)
{
    if (path.empty())
        return false;

    WINTRUST_FILE_INFO fileInfo{};
    fileInfo.cbStruct = sizeof(fileInfo);
    fileInfo.pcwszFilePath = path.c_str();

    GUID policyGUID =
        WINTRUST_ACTION_GENERIC_VERIFY_V2;

    WINTRUST_DATA trustData{};
    trustData.cbStruct = sizeof(trustData);
    trustData.dwUIChoice = WTD_UI_NONE;
    trustData.fdwRevocationChecks = WTD_REVOKE_NONE;
    trustData.dwUnionChoice = WTD_CHOICE_FILE;
    trustData.pFile = &fileInfo;
    trustData.dwStateAction = WTD_STATEACTION_VERIFY;

    LONG status = WinVerifyTrust(
        nullptr,
        &policyGUID,
        &trustData);

    trustData.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust(
        nullptr,
        &policyGUID,
        &trustData);

    if (status != ERROR_SUCCESS)
        return false;

    // A valid Authenticode result is useful evidence even when the
    // certificate subject is not extracted here.
    signer = L"Authenticode signature valid";
    return true;
}

void ProcessScanner::ValidateSignature(ProcessInfo& p)
{
    if (!p.pathResolved)
        return;

    p.signatureValid =
        VerifyAuthenticode(p.path, p.signer);

    if (IsSystemProcessName(p.name) &&
        !p.signatureValid)
    {
        AddFinding(
            p,
            30,
            L"Signature",
            L"Known Windows process has no valid Authenticode signature");
    }
}

std::wstring ProcessScanner::Sha256File(
    const std::wstring& path)
{
    HANDLE file = CreateFileW(
        path.c_str(),
        GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);

    if (file == INVALID_HANDLE_VALUE)
        return L"";

    HCRYPTPROV prov = 0;
    HCRYPTHASH hash = 0;

    if (!CryptAcquireContextW(
            &prov,
            nullptr,
            nullptr,
            PROV_RSA_AES,
            CRYPT_VERIFYCONTEXT))
    {
        CloseHandle(file);
        return L"";
    }

    if (!CryptCreateHash(
            prov,
            CALG_SHA_256,
            0,
            0,
            &hash))
    {
        CryptReleaseContext(prov, 0);
        CloseHandle(file);
        return L"";
    }

    BYTE buffer[1024 * 1024];
    DWORD read = 0;
    bool ok = true;

    while (ReadFile(
        file,
        buffer,
        sizeof(buffer),
        &read,
        nullptr) && read != 0)
    {
        if (!CryptHashData(
                hash,
                buffer,
                read,
                0))
        {
            ok = false;
            break;
        }
    }

    std::wstring output;

    if (ok)
    {
        BYTE digest[32]{};
        DWORD digestSize = sizeof(digest);

        if (CryptGetHashParam(
                hash,
                HP_HASHVAL,
                digest,
                &digestSize,
                0))
        {
            std::wstringstream ss;

            for (DWORD i = 0; i < digestSize; ++i)
            {
                ss << std::hex
                   << std::setw(2)
                   << std::setfill(L'0')
                   << static_cast<int>(digest[i]);
            }

            output = ss.str();
        }
    }

    CryptDestroyHash(hash);
    CryptReleaseContext(prov, 0);
    CloseHandle(file);

    return output;
}

void ProcessScanner::IdentifyHash(ProcessInfo& p)
{
    if (!p.pathResolved)
        return;

    p.sha256 = Sha256File(p.path);

    if (p.sha256.empty())
    {
        AddFinding(
            p,
            5,
            L"Hash",
            L"Could not calculate SHA-256");
    }
}

void ProcessScanner::ValidateKnownNamePath(ProcessInfo& p)
{
    if (!p.pathResolved)
        return;

    if (!IsSystemProcessName(p.name))
        return;

    p.isWindowsSystemProcess = true;

    if (!IsExpectedSystemPath(p.name, p.path))
    {
        AddFinding(
            p,
            45,
            L"Identity",
            L"Known Windows process name with unexpected executable path");
    }
}

void ProcessScanner::ValidateModules(ProcessInfo& p)
{
    if (!p.pathResolved)
        return;

    // Toolhelp module inspection is intentionally limited to the target's
    // module list. Failure to inspect is not treated as malicious.
    HANDLE snapshot = CreateToolhelp32Snapshot(
        TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32,
        p.pid);

    if (snapshot == INVALID_HANDLE_VALUE)
        return;

    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);

    bool mainModuleFound = false;

    if (Module32FirstW(snapshot, &me))
    {
        do
        {
            const auto modulePath = ToLower(me.szExePath);

            if (ToLower(modulePath) == ToLower(p.path))
                mainModuleFound = true;

            // System processes loading an executable module from Temp is
            // a stronger anomaly than the executable itself being in Temp.
            if (p.isWindowsSystemProcess &&
                (ContainsI(modulePath, L"\\temp\\") ||
                 ContainsI(modulePath, L"\\appdata\\local\\temp\\")))
            {
                AddFinding(
                    p,
                    25,
                    L"Modules",
                    L"Windows system process has a module loaded from a temporary path");
            }

        } while (Module32NextW(snapshot, &me));
    }

    CloseHandle(snapshot);

    if (!mainModuleFound && p.pathResolved)
    {
        // This can happen because of access restrictions; keep the weight low.
        AddFinding(
            p,
            5,
            L"Modules",
            L"Main executable was not confirmed in the accessible module list");
    }
}

void ProcessScanner::CheckMemoryModuleAnomalies(ProcessInfo& p)
{
    // Conservative user-mode checks only.
    // We do not classify arbitrary JMP instructions as malicious.
    //
    // A real memory-integrity engine should compare loaded PE sections against
    // a trusted on-disk image and account for legitimate relocations, CFG,
    // hotpatching, import thunks and runtime-generated code.
    //
    // Here we only flag a high-risk combination that is observable without
    // undocumented kernel interfaces.
    if (!p.pathResolved)
        return;

    if (p.isWindowsSystemProcess &&
        !p.signatureValid &&
        !ContainsI(p.path, L"\\windows\\"))
    {
        AddFinding(
            p,
            20,
            L"Memory/Module",
            L"System-named process is unsigned and outside the Windows directory");
    }
}

void ProcessScanner::AnalyzeProcess(
    ProcessInfo& p,
    const std::unordered_map<DWORD, ProcessInfo*>& byPid)
{
    ValidatePath(p);
    ValidateParent(p, byPid);
    ValidateSignature(p);
    IdentifyHash(p);
    ValidateKnownNamePath(p);
    ValidateModules(p);
    CheckMemoryModuleAnomalies(p);

    FinalizeScore(p);
}

std::vector<ProcessInfo> ProcessScanner::Scan()
{
    auto processes = EnumerateProcesses();

    std::unordered_map<DWORD, ProcessInfo*> byPid;

    for (auto& p : processes)
        byPid[p.pid] = &p;

    for (auto& p : processes)
        AnalyzeProcess(p, byPid);

    return processes;
}

# Windows Process Scanner
Feito Por: Alone
Discord: constipei

## Pipeline

Process enumeration
- Path validation
- Parent validation
- Authenticode validation
- SHA-256 identification
- Known-name/path mismatch
- Module validation
- Conservative memory/module anomaly checks
- Risk scoring

## Score

- LOW: 0-29
- MEDIUM: 30-59
- HIGH: 60+

O score é heurístico. Um alerta não significa automaticamente malware ou rootkit.

## Compilação

Requisitos:
- Windows
- Visual Studio 2022 ou Build Tools
- CMake 3.20+

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\WindowsProcessScanner.exe
```

Algumas verificações exigem privilégios maiores para determinados processos. Execute como administrador somente quando necessário e apropriado.

## Observações

Esta versão evita:
- DKOM
- manipulação de EPROCESS
- SSDT hooking
- ocultação de processos
- alteração de memória de outros processos

Ela é voltada para **detecção/análise**, não para modificar ou esconder processos.

As verificações de módulos e memória são deliberadamente conservadoras para reduzir falsos positivos.
